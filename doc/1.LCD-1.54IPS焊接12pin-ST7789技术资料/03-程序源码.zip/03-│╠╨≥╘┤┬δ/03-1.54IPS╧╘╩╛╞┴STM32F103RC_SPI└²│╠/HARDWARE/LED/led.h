#ifndef __LED_H
#define __LED_H

#include "sys.h"



#define LED PCout(12)	// PC12

void LED_Init(void);


#endif




